"#ScoolSales" 
